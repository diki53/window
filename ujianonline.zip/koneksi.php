<?php

$mysqli = new mysqli('localhost','root','','db_ujian');

